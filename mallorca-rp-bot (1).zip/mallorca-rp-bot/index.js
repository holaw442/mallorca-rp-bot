require('dotenv').config();
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commands = [
  new SlashCommandBuilder()
    .setName('arrestar')
    .setDescription('Arrestar a un usuario')
    .addUserOption(opt => opt.setName('usuario').setDescription('Usuario arrestado').setRequired(true))
    .addStringOption(opt => opt.setName('tiempo').setDescription('Duración del arresto').setRequired(true))
    .addAttachmentOption(opt => opt.setName('foto').setDescription('Foto del arresto').setRequired(true)),
  new SlashCommandBuilder()
    .setName('multar')
    .setDescription('Multar a un usuario')
    .addUserOption(opt => opt.setName('usuario').setDescription('Usuario multado').setRequired(true))
    .addStringOption(opt => opt.setName('articulos').setDescription('Artículos incumplidos').setRequired(true)),
  new SlashCommandBuilder()
    .setName('ck')
    .setDescription('Registrar una muerte definitiva (CK)')
    .addUserOption(opt => opt.setName('usuario').setDescription('Usuario CK').setRequired(true))
    .addStringOption(opt =>
      opt.setName('tipo')
        .setDescription('Tipo de muerte')
        .addChoices({ name: 'Suicidio', value: 'Suicidio' }, { name: 'Muerte', value: 'Muerte' })
        .setRequired(true))
].map(c => c.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
(async () => {
  try {
    await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), { body: commands });
    console.log('✅ Comandos registrados');
  } catch (err) {
    console.error(err);
  }
})();

client.once('ready', () => console.log(`✅ Bot conectado como ${client.user.tag}`));

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const now = new Intl.DateTimeFormat('es-ES', {
    dateStyle: 'full',
    timeStyle: 'short'
  }).format(new Date());

  const user = interaction.options.getUser('usuario');
  if (interaction.commandName === 'arrestar') {
    const tiempo = interaction.options.getString('tiempo');
    const foto = interaction.options.getAttachment('foto');
    const embed = new EmbedBuilder()
      .setTitle('👮 Arresto').setColor('Blue').setThumbnail(foto.url)
      .addFields(
        { name: '👤 Arrestado', value: `${user}`, inline: true },
        { name: '⏱️ Tiempo', value: tiempo, inline: true },
        { name: '👮 Oficial', value: `${interaction.user}`, inline: true },
        { name: '📅 Fecha', value: now, inline: false }
      );
    return interaction.reply({ embeds: [embed] });
  }

  if (interaction.commandName === 'multar') {
    const articulos = interaction.options.getString('articulos');
    const embed = new EmbedBuilder()
      .setTitle('💸 Multa').setColor('Orange')
      .addFields(
        { name: '👤 Usuario', value: `${user}`, inline: true },
        { name: '📜 Artículos', value: articulos, inline: true },
        { name: '👮 Oficial', value: `${interaction.user}`, inline: true },
        { name: '📅 Fecha', value: now, inline: false }
      );
    return interaction.reply({ embeds: [embed] });
  }

  if (interaction.commandName === 'ck') {
    const tipo = interaction.options.getString('tipo');
    const embed = new EmbedBuilder()
      .setTitle('☠️ CK (Muerte definitiva)').setColor('DarkRed')
      .addFields(
        { name: '👤 Usuario', value: `${user}`, inline: true },
        { name: '🧠 Tipo de muerte', value: tipo, inline: true },
        { name: '📅 Fecha', value: now, inline: false },
        { name: '👮 Registrado por', value: `${interaction.user}`, inline: false }
      );
    return interaction.reply({ embeds: [embed] });
  }
});

client.login(process.env.DISCORD_TOKEN);
